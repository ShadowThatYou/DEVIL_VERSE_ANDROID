module.exports = {
  tokens: "7948891983:AAEdwFPdb7RUZRZw8OM-CwXJqqUE1neZ1_k",  // Ubah Jadi Token Bot Mu !!!
  owner: "7205193471", // Ubah Jadi Id Mu !!!
  port: "3206", // Ubah Jadi Port Panel Mu !!!
  ipvps: "https://blueserverpanel.bluesrv.web.id" // Ubah Jadi Ip Vps Mu !!!
};